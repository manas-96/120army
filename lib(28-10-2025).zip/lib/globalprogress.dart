import 'package:flutter/material.dart';

/// Upload progress ke globally track korte
ValueNotifier<double> uploadProgress = ValueNotifier(0.0);

ValueNotifier<double> reelsuploadProgress = ValueNotifier(0.0);
