import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../model/listpost_model.dart';
import '../services/main_service.dart';
import '../exports.dart';
import 'widget/postdetailstext.dart';
import 'widget/likecommentshare.dart';

class Reelslist extends StatefulWidget {
  const Reelslist({super.key});

  @override
  State<Reelslist> createState() => _ReelslistState();
}

class _ReelslistState extends State<Reelslist> {
  List<PostlistDatum> reelsList = [];
  bool isLoading = true;
  bool isLoadingMore = false;
  bool hasMore = true;
  int currentPage = 1;
  final PageController _pageController = PageController();

  // Current playing index track করবো
  int _currentPlayingIndex = 0;

  // Preload এর জন্য next index
  int _preloadIndex = -1;

  @override
  void initState() {
    super.initState();
    _loadReels();
    _pageController.addListener(_scrollListener);
  }

  void _scrollListener() {
    // Current page track করুন
    final currentPage = _pageController.page?.round() ?? 0;
    if (currentPage != _currentPlayingIndex) {
      setState(() {
        _currentPlayingIndex = currentPage;
        // Preload next video (max 1 ahead)
        _preloadIndex = currentPage + 1;
      });
    }

    if (_pageController.position.pixels >=
            _pageController.position.maxScrollExtent - 200 &&
        !isLoadingMore &&
        hasMore) {
      _loadMoreReels();
    }
  }

  Future<void> _loadReels() async {
    try {
      setState(() {
        isLoading = true;
        currentPage = 1;
      });

      final data = await MainService().reelsListService(page: currentPage);
      final loadedReels = data.data.where((r) => r.files.isNotEmpty).toList();

      setState(() {
        reelsList = loadedReels;
        isLoading = false;
        hasMore = data.data.isNotEmpty;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients && reelsList.isNotEmpty) {
          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted) {
              _pageController.jumpToPage(0);
            }
          });
        }
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      log("Error loading Clips: $e");
    }
  }

  Future<void> _loadMoreReels() async {
    if (isLoadingMore || !hasMore) return;

    try {
      setState(() {
        isLoadingMore = true;
      });

      final nextPage = currentPage + 1;
      final data = await MainService().reelsListService(page: nextPage);
      final newReels = data.data.where((r) => r.files.isNotEmpty).toList();

      setState(() {
        reelsList.addAll(newReels);
        currentPage = nextPage;
        isLoadingMore = false;
        hasMore = data.data.isNotEmpty;
      });
    } catch (e) {
      setState(() {
        isLoadingMore = false;
      });
      log("Error loading more Clips: $e");
    }
  }

  Future<void> _refreshReels() async {
    try {
      final data = await MainService().reelsListService(page: 1);
      final loadedReels = data.data.where((r) => r.files.isNotEmpty).toList();

      setState(() {
        reelsList = loadedReels;
        currentPage = 1;
        hasMore = data.data.isNotEmpty;
        _currentPlayingIndex = 0;
        _preloadIndex = -1;
      });

      if (_pageController.hasClients && reelsList.isNotEmpty) {
        _pageController.jumpToPage(0);
      }
    } catch (e) {
      log("Error refreshing Clips: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Refresh failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _deleteReel(int index, int reelId) {
    setState(() {
      reelsList.removeAt(index);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_pageController.hasClients && reelsList.isNotEmpty) {
        final newIndex =
            index >= reelsList.length ? reelsList.length - 1 : index;
        _pageController.jumpToPage(newIndex);
      }
    });

    MainService().deletepostService(id: reelId);
  }

  @override
  void dispose() {
    _pageController.removeListener(_scrollListener);
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: RefreshIndicator(
        backgroundColor: Colors.black,
        color: Colors.white,
        strokeWidth: 2.0,
        onRefresh: _refreshReels,
        child: PageView.builder(
          controller: _pageController,
          scrollDirection: Axis.vertical,
          itemCount: reelsList.length + (hasMore ? 1 : 0),
          onPageChanged: (index) {
            // Manual page change handling
            if (index < reelsList.length) {
              setState(() {
                _currentPlayingIndex = index;
                // Preload next video only
                _preloadIndex = index + 1;
              });
            }
          },
          itemBuilder: (context, index) {
            if (index >= reelsList.length) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              );
            }

            final reel = reelsList[index];
            return ReelItem(
              key: ValueKey('reel_${reel.id}_$index'),
              videoUrl: reel.files[0].fileUrls,
              index: index,
              item: reel,
              onDelete: () => _deleteReel(index, reel.id),
              shouldPlay: index == _currentPlayingIndex,
              shouldPreload:
                  index == _preloadIndex && _preloadIndex < reelsList.length,
            );
          },
        ),
      ),
    );
  }
}

// -------------------- Reel Item --------------------
class ReelItem extends StatefulWidget {
  final String videoUrl;
  final int index;
  final PostlistDatum item;
  final VoidCallback onDelete;
  final bool shouldPlay;
  final bool shouldPreload;

  const ReelItem({
    super.key,
    required this.videoUrl,
    required this.index,
    required this.item,
    required this.onDelete,
    required this.shouldPlay,
    required this.shouldPreload,
  });

  @override
  State<ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<ReelItem> {
  VideoPlayerController? _controller;
  bool isInitialized = false;
  bool _isDisposed = false;
  bool _wasPlaying = false;
  bool _isPreloaded = false;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  @override
  void didUpdateWidget(ReelItem oldWidget) {
    super.didUpdateWidget(oldWidget);

    // যদি video URL change হয়
    if (oldWidget.videoUrl != widget.videoUrl) {
      _disposeController();
      _initializeVideo();
    }

    // Preload condition change হলে
    if (oldWidget.shouldPreload != widget.shouldPreload &&
        widget.shouldPreload &&
        !_isPreloaded) {
      _preloadVideo();
    }

    // Play/pause state change হলে handle করুন
    if (oldWidget.shouldPlay != widget.shouldPlay) {
      _handlePlayPause();
    }
  }

  Future<void> _initializeVideo() async {
    try {
      // যদি already initialized থাকে তবে return
      if (_controller != null && _controller!.value.isInitialized) return;

      _controller = VideoPlayerController.network(widget.videoUrl);

      await _controller!
          .initialize()
          .then((_) {
            if (_isDisposed) {
              _controller?.dispose();
              return;
            }

            if (mounted) {
              setState(() {
                isInitialized = true;
              });
              _controller!.setLooping(true);

              // প্রথমবার initialize এ play করবো যদি shouldPlay true হয়
              if (widget.shouldPlay) {
                _playVideo();
              }
            }
          })
          .catchError((error) {
            log("Video initialization error: $error");
            _retryInitialization();
          });
    } catch (e) {
      log("Error in video initialization: $e");
      _retryInitialization();
    }
  }

  Future<void> _preloadVideo() async {
    if (_isPreloaded || _controller != null) return;

    try {
      _controller = VideoPlayerController.network(widget.videoUrl);
      await _controller!.initialize();

      if (_isDisposed) {
        _controller?.dispose();
        return;
      }

      if (mounted) {
        setState(() {
          isInitialized = true;
          _isPreloaded = true;
        });
        _controller!.setLooping(true);

        // Preloaded video কে pause করে রাখবো
        _controller!.pause();
      }
    } catch (e) {
      log("Preload error: $e");
    }
  }

  void _disposeController() {
    if (_controller != null) {
      _controller!.pause();
      _controller!.dispose();
      _controller = null;
    }
    setState(() {
      isInitialized = false;
      _isPreloaded = false;
    });
  }

  void _retryInitialization() {
    Future.delayed(const Duration(seconds: 2), () {
      if (!_isDisposed && mounted) {
        _initializeVideo();
      }
    });
  }

  void _handlePlayPause() {
    if (!isInitialized || _isDisposed || _controller == null) return;

    if (widget.shouldPlay) {
      _playVideo();
    } else {
      _pauseVideo();
    }
  }

  void _playVideo() {
    if (_controller != null &&
        !_controller!.value.isPlaying &&
        _controller!.value.isInitialized) {
      // Small delay to prevent buffer issues
      Future.delayed(const Duration(milliseconds: 50), () {
        if (!_isDisposed &&
            mounted &&
            _controller != null &&
            _controller!.value.isInitialized) {
          _controller!.play();
          _wasPlaying = true;
        }
      });
    }
  }

  void _pauseVideo() {
    if (_controller != null && _controller!.value.isPlaying) {
      _controller!.pause();
      _wasPlaying = false;

      // Clear video buffer when pausing to free memory
      Future.delayed(const Duration(milliseconds: 100), () {
        if (!_isDisposed && mounted && _controller != null) {
          // Seek to current position to clear buffers
          final currentPosition = _controller!.value.position;
          _controller!.seekTo(currentPosition);
        }
      });
    }
  }

  void _onTapVideo() {
    if (!isInitialized || _controller == null) return;

    if (_controller!.value.isPlaying) {
      _pauseVideo();
    } else {
      _playVideo();
    }
    setState(() {});
  }

  void _clearBuffers() {
    if (_controller != null && _controller!.value.isInitialized) {
      // Clear buffers by seeking to current position
      final currentPosition = _controller!.value.position;
      _controller!.seekTo(currentPosition);
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    if (_controller != null) {
      _controller!.pause();
      _controller!.dispose();
      _controller = null;
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Automatically handle play/pause based on shouldPlay
    if (isInitialized && _controller != null) {
      if (widget.shouldPlay && !_controller!.value.isPlaying && _wasPlaying) {
        _playVideo();
      } else if (!widget.shouldPlay && _controller!.value.isPlaying) {
        _pauseVideo();
      }
    }

    // Preload video if needed
    if (widget.shouldPreload && !_isPreloaded && _controller == null) {
      _preloadVideo();
    }

    return GestureDetector(
      onTap: _onTapVideo,
      onDoubleTap: _clearBuffers,
      child: Stack(
        children: [
          // Video Player
          Positioned.fill(child: _buildVideoPlayer()),

          // Bottom Text
          Positioned(
            left: 16,
            bottom: 30,
            right: 16,
            child: Postdetailstext(
              index: widget.index,
              item: widget.item,
              onDelete: widget.onDelete,
              reele: true,
            ),
          ),

          // Like Comment Share
          Positioned(
            right: 10,
            bottom: 120,
            child: Likecommentshare(
              reels: true,
              postid: widget.item.id.toString(),
              commentcount: widget.item.commentCount,
              likescount: widget.item.likes,
              isLiked: widget.item.isLiked,
              onLikeToggle: () async {
                final currentLiked = widget.item.isLiked == 1;
                await MainService().likeunlikeService(
                  id: widget.item.id,
                  isLiked: currentLiked,
                );

                setState(() {
                  widget.item.isLiked = currentLiked ? 0 : 1;
                  widget.item.likes += currentLiked ? -1 : 1;
                });
              },
            ),
          ),

          // Progress Bar
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child:
                isInitialized && _controller != null
                    ? VideoProgressBar(controller: _controller!)
                    : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!isInitialized || _controller == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final isPortrait =
        _controller!.value.size.height > _controller!.value.size.width;

    if (isPortrait) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller!.value.size.width,
            height: _controller!.value.size.height,
            child: VideoPlayer(_controller!),
          ),
        ),
      );
    } else {
      return Center(
        child: AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        ),
      );
    }
  }
}

// -------------------- Video Progress Bar --------------------
class VideoProgressBar extends StatefulWidget {
  final VideoPlayerController controller;
  const VideoProgressBar({super.key, required this.controller});

  @override
  State<VideoProgressBar> createState() => _VideoProgressBarState();
}

class _VideoProgressBarState extends State<VideoProgressBar> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final position = widget.controller.value.position;
    final duration = widget.controller.value.duration;

    final progress =
        duration.inMilliseconds == 0
            ? 0.0
            : position.inMilliseconds / duration.inMilliseconds;

    return LinearProgressIndicator(
      value: progress,
      backgroundColor: Colors.white.withOpacity(0.3),
      color: Colors.blue,
      minHeight: 3,
    );
  }
}
