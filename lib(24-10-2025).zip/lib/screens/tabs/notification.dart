import 'package:onetwentyarmyprayer2/global.dart';

import '../../exports.dart';
import '../widget/bgcolorprayicon.dart';
import '../widget/colorcommenticon.dart';

class Notificationtab extends StatefulWidget {
  const Notificationtab({super.key});

  @override
  State<Notificationtab> createState() => _NotificationtabState();
}

class _NotificationtabState extends State<Notificationtab> {
  // final List<Map<String, dynamic>> notificationdata = [
  //   {"status": 0},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 1},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 2},
  //   {"status": 2},
  //   {"status": 0},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 1},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 0},
  //   {"status": 1},
  //   {"status": 2},
  //   {"status": 2},
  // ];

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: tabTopPadding),
        child: Center(child: Text("No data found")),
        // child: ListView.builder(
        //   padding: EdgeInsets.all(0),
        //   itemCount: notificationdata.length,
        //   itemBuilder: (context, index) {
        //     return Container(
        //       width: size.width,
        //       margin: EdgeInsets.only(
        //         bottom:
        //             index == notificationdata.length - 1
        //                 ? hometabbottomgap - 20
        //                 : 0,
        //       ),
        //       padding: EdgeInsets.symmetric(
        //         vertical: 10,
        //         horizontal: kDefaultPadding - 10,
        //       ),
        //       child: Row(
        //         crossAxisAlignment: CrossAxisAlignment.center,
        //         mainAxisAlignment: MainAxisAlignment.center,
        //         spacing: 10,
        //         children: [
        //           Container(
        //             decoration: BoxDecoration(
        //               borderRadius: BorderRadius.circular(60),
        //             ),
        //             child: Stack(
        //               clipBehavior: Clip.none,
        //               children: [
        //                 ClipRRect(
        //                   borderRadius: BorderRadius.circular(60),
        //                   child: Image.asset(
        //                     "assets/images/avater.jpg",
        //                     width: 60,
        //                   ),
        //                 ),
        //                 Positioned(
        //                   right: 0,
        //                   bottom: 0,
        //                   child:
        //                       notificationdata[index]["status"] == 0
        //                           ? Bgcolorprayicon()
        //                           : Colorcommenticon(),
        //                 ),
        //               ],
        //             ),
        //           ),
        //           Expanded(
        //             // Make the text flexible
        //             child: Column(
        //               crossAxisAlignment: CrossAxisAlignment.start,
        //               children: [
        //                 Text.rich(
        //                   TextSpan(
        //                     children: [
        //                       TextSpan(
        //                         text: 'Kevin Pietersen ',
        //                         style: TextStyle(fontWeight: FontWeight.w700),
        //                       ),
        //                       if (notificationdata[index]["status"] == 0)
        //                         TextSpan(text: 'liked your prayer post.')
        //                       else
        //                         TextSpan(
        //                           text: 'commented on your prayer post.',
        //                         ),
        //                     ],
        //                   ),
        //                   softWrap: true,
        //                 ),
        //               ],
        //             ),
        //           ),
        //         ],
        //       ),
        //     );
        //   },
        // ),
      ),
    );
  }
}
