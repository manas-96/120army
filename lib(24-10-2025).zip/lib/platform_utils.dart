// platform_utils.dart
import 'dart:io';

bool isAndroid() => Platform.isAndroid;
bool isIOS() => Platform.isIOS;
